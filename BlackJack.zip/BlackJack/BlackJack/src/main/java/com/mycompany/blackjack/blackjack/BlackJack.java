package com.mycompany.blackjack.blackjack;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */


/**
 *
 * @author kiswo
 */
public class BlackJack {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
